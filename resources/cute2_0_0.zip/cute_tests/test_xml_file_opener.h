#include "cute_suite.h"

extern cute::suite make_suite_test_xml_file_opener();
