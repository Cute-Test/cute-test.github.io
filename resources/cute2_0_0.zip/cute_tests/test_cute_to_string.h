/*
 * test_cute_stream_out.h
 *
 *  Created on: 31.05.2013
 *      Author: sop
 */

#ifndef TEST_CUTE_TO_STRING_H_
#define TEST_CUTE_TO_STRING_H_

#include "cute_suite.h"
extern cute::suite test_cute_to_string();



#endif /* TEST_CUTE_TO_STRING_H_ */
